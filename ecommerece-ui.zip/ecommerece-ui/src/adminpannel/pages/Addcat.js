import React from 'react'
import CustomInput from '../components/CustomInput'
import AdminBreadCrum from '../components/AdminBreadCrum';
import { AdminMeta } from '../components/AdminMeta';
const Addcat = () => {
  return (
    <div>
      <AdminMeta title={"Add Category"} />
      <AdminBreadCrum title='Add Category' />
      <div>
        <form action=''>
          <CustomInput type='text' label='Enter Category' />
          <button className='btn btn-success border-0 rounded-3 my-5'
            type='submit'
            style={{ background: "#F06331" }}>Add Category</button>
        </form>
      </div>
    </div>
  )
}

export default Addcat