import React from 'react'
import CustomInput from '../components/CustomInput'
import AdminBreadCrum from '../components/AdminBreadCrum';
import { AdminMeta } from '../components/AdminMeta';
const Addcolor = () => {
  return (
    <div>
      <AdminMeta title={"Add Color"} />
      <AdminBreadCrum title='Add Color' />
      <div>
        <form action=''>
          <CustomInput type='color' label='Enter Color' />
          <button className='btn btn-success border-0 rounded-3 my-5'
            type='submit'
            style={{ background: "#F06331" }}>Add Blog</button>
        </form>
      </div>
    </div>
  )
}

export default Addcolor