import React from 'react'
import CustomInput from '../components/CustomInput'
import AdminBreadCrum from '../components/AdminBreadCrum';
import { AdminMeta } from '../components/AdminMeta';
const Addbrand = () => {
  return (
    <div>
      <AdminMeta title={"Add Brand"} />
      <AdminBreadCrum title='Add Brand' />
      <div>
        <form action=''>
          <CustomInput type='text' label='Enter Brand' />
          <button className='btn btn-success border-0 rounded-3 my-5'
            type='submit'
            style={{ background: "#F06331" }}>Add Brand</button>
        </form>
      </div>
    </div>
  )
}

export default Addbrand