import React from 'react'
import { BreadCrum } from '../components/BreadCrum'
import { Meta } from '../components/Meta'
const SingleProduct = () => {
    return <>
        <Meta title={"Single Product"} />
        <BreadCrum title='Single Product' />
    </>
}

export default SingleProduct