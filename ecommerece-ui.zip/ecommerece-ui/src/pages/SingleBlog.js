import React from 'react'
import { BreadCrum } from '../components/BreadCrum'
import { Meta } from '../components/Meta'
import BlogCard from '../components/BlogCard'
import { Link } from 'react-router-dom'
import { HiOutlineArrowLeft } from 'react-icons/hi'
const SingleBlog = () => {
  return <>
    <Meta title={"Dynamic Blog"} />
    <BreadCrum title='Dynamic Blog' />
    <div className='blog-wrapper home-wrapper-2 py-5'>
      <div className='container-xxl'>
        <div className='row'>
          <div className='col-12'>
            <div className='single-blog-card'>
              <Link to='/blog' className='d-flex align-items-center gap10'>
                <HiOutlineArrowLeft className='fs-5' /> Go Back to Blogs
              </Link>
              <h3 className='title'>A sunday morning ressiance</h3>
              <img src='../images/blog-1.jpg' alt='blog' className='img-fluid w-100 my-4' />
              <p>
                Dark chocolate contains 50-90% cocoa solids, cocoa butter, and sugar, whereas milk chocolate contains anywhere from 10-50% cocoa solids, cocoa butter, milk in some form, and sugar.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
}

export default SingleBlog