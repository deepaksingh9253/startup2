import React from 'react'
import ReactStars from "react-rating-stars-component";
import { Link, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import axios from 'axios';
import { useState } from 'react';
export const ProductCard = (props) => {
    const [data, setData]=useState([]);
    useEffect(()=>{
        axios('http://localhost:4000/products')   //  http://srv407359.hstgr.cloud:5001/product/products   
        .then(res=>setData(res.data))
        // .then(res=>console.log(res.data))   //http://localhost:4000/products
        .catch(err=>console.log(err))
    },[])
    const { grid } = props
    let location = useLocation();
    // console.log(location);
    return (
        data.map((item, index)=>
        <div className={`${location.pathname == "/store" ? `gr-${grid}` : "col-3"}`}>
            <Link className='product-card position-relative'>
                <div className='wishlist-icon position-absolute'>
                    <Link><img src='images/wish.svg' alt='wishlist' /></Link>
                </div>
                <div className='product-image'>
                    <img src={`${item.images[0].url}`} className='img-fluid' alt='product image' />
                    <img src='images/chocolate2.png' className='img-fluid' alt='product image' />
                </div>
                <div className='product-details'>
                    <h6 className='brand'>{item.brand}</h6>
                    <h5 className='product-tittle'>
                    {item.title}
                    </h5>
                    <ReactStars
                        count={5}
                        size={24}
                        value={4}
                        edit={false}
                        activeColor="#ffd700"
                    />
                    <p className={`description ${grid===12 ? "d-block":"d-none"}`}>
                   {item.description}
                    </p>
                    <p className='price'>$100.00</p>
                </div>
                <div className='action-bar position-absolute'>
                    <div className='d-flex flex-column gap15'>
                        <Link><img src='images/prodcompare.svg' alt='compare' /></Link>
                        <Link><img src='images/view.svg' alt='view' /></Link>
                        <Link><img src='images/add-cart.svg' alt='addcart' /></Link>

                    </div>
                </div>
            </Link>
        </div>
        )
    )
}
